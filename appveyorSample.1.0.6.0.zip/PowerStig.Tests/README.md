# PowerStig.Tests

Shared functions for PowerStig repositories.

## Branches

### master

[![Build status](https://ci.appveyor.com/api/projects/status/ju2mk52h6gjw6tlg/branch/master?svg=true)](https://ci.appveyor.com/project/athaynes/powerstig-tests/branch/master)
[![codecov](https://codecov.io/gh/Microsoft/PowerStig.Tests/branch/master/graph/badge.svg)](https://codecov.io/gh/Microsoft/PowerStig.Tests)

This is the branch containing the latest release - no contributions should be made
directly to this branch.

### dev

[![Build status](https://ci.appveyor.com/api/projects/status/ju2mk52h6gjw6tlg/branch/dev?svg=true)](https://ci.appveyor.com/project/athaynes/powerstig-tests/branch/dev)
[![codecov](https://codecov.io/gh/Microsoft/PowerStig.Tests/branch/dev/graph/badge.svg)](https://codecov.io/gh/Microsoft/PowerStig.Tests)

This is the development branch to which contributions should be proposed by contributors
as pull requests.
This branch is used by DSC Resource Kit modules for running common tests.

## Contributing

This project welcomes contributions and suggestions.  Most contributions require you to agree to a
Contributor License Agreement (CLA) declaring that you have the right to, and actually do, grant us
the rights to use your contribution. For details, visit https://cla.microsoft.com.

When you submit a pull request, a CLA-bot will automatically determine whether you need to provide
a CLA and decorate the PR appropriately (e.g., label, comment). Simply follow the instructions
provided by the bot. You will only need to do this once across all repos using our CLA.

This project has adopted the [Microsoft Open Source Code of Conduct](https://opensource.microsoft.com/codeofconduct/).
For more information see the [Code of Conduct FAQ](https://opensource.microsoft.com/codeofconduct/faq/) or
contact [opencode@microsoft.com](mailto:opencode@microsoft.com) with any additional questions or comments.
