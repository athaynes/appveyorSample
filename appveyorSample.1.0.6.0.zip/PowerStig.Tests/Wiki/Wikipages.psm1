#region Strings

$header = @'
# {0} Class

{1}
'@

$constructorHeader = @'

## Constructors

| Name | Description |
|-|-|
'@

$propertiesHeader = @'

## Properties

| Name | Description |
|-|-|
'@

$methodsHeader = @'

## Methods

| Name | Description |
|-|-|
'@

$examplesHeader = @'

## Example
'@

#endregion

function Get-WikiContent
{
    [OutputType([hashtable])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [string]
        $Path
    )

    $input = Get-Content -Path $Path -Raw

    [System.Management.Automation.Language.Token[]] $tokens = $null

    $ast = [System.Management.Automation.Language.Parser]::ParseInput(
        $input, [ref]$tokens, [ref]$null)

    $return = [System.Collections.Specialized.OrderedDictionary]@{}
    <#
        1. Get the Type Definition and Build a hashtable for the
            a. Class
            b. Constructors
            c. Properties
            d. Methods

        2. Modify the Class definition in memory to replace key words with the function key word
        3. Parse the updated script file
        4. Search for FunctionDefinitionAst to get access to GetHelpContent
        5. Update each item in the hashtable from step one with it's help content.
    #>

    $TypeDefinitionAst = $ast.FindAll(
        {$args[0] -is [System.Management.Automation.Language.TypeDefinitionAst ]}, $true)

    $return.Add(
        "Class.$($TypeDefinitionAst.Extent.StartLineNumber)",
        @{
            Name = $TypeDefinitionAst.Name
        }
    )

    #Properties
    foreach ($entry in $TypeDefinitionAst.Members.Where( {$PSItem.PropertyType -ne $null}))
    {
        $details = @{
            Name = $entry.Name
            LineNumber = $entry.Extent.StartLineNumber
            PropertyType = $entry.PropertyType.TypeName.FullName
            MethodAttributes = $entry.MethodAttributes
            Link = "[Property.$($entry.Name)]: Stig.OrganizationalSettings.Class.Syntax#property$($entry.Name.ToLower())"
        }
        $return.Add("Property.$($entry.Extent.StartLineNumber)", $details)
    }

    # Constructors
    foreach ($entry in $TypeDefinitionAst.Members.Where( {$PSItem.Name -eq $TypeDefinitionAst.Name}))
    {
        $details = @{
            Name = $entry.Name
            LineNumber = $entry.Extent.StartLineNumber
            MethodAttributes = $entry.MethodAttributes
            Parameters = $entry.Parameters
        }

        if ($details.Parameters.Count -gt 0)
        {
            $parameterType = $entry.Parameters.Attributes.TypeName.Name -join "."
            $linkpath = "Constructor.$parameterType"
        }
        else
        {
            $linkpath = "Constructor"
        }

        $details.Add('Link', "[$linkpath]: Stig.$($TypeDefinitionAst.Name).Class.Syntax#$($linkpath.ToLower() -replace "\.",'')")
        $return.Add("Constructor.$($entry.Extent.StartLineNumber)", $details)
    }

    #Methods
    foreach ($entry in $TypeDefinitionAst.Members.Where( {$PSItem.Name -ne $TypeDefinitionAst.Name -and
                $PSItem.MethodAttributes -ne $null}))
    {
        $details = @{
            Name = $entry.Name
            LineNumber = $entry.Extent.StartLineNumber
            PropertyType = $entry.PropertyType.TypeName.FullName
            MethodAttributes = $entry.MethodAttributes
            ReturnType = $entry.ReturnType.TypeName.FullName
            Parameters = $entry.Parameters
        }

        if ($details.Parameters.Count -gt 0)
        {
            $parameterType = $entry.Parameters.Attributes.TypeName.Name
            $linkpath = "Method.$($entry.Name).$parameterType"
        }
        else
        {
            $linkpath = "Method.$($entry.Name)"
        }
        $details.Add('Link', "[$linkpath]: Stig.OrganizationalSettings.Class.Syntax#$($linkpath.ToLower() -replace "\.",'')")
        $return.Add("Method.$($entry.Extent.StartLineNumber)", $details)
    }

    # Update the content with the function keyword to extract help content
    $classAndConstructorFilter = "^(Class)?\s+$($TypeDefinitionAst.Name)"
    $methodFilter = '^\s*(static)?\s*\[\w*(\[(\s*)?\])?\]\s*'

    $inputModified = (($input -split "`n") -replace $classAndConstructorFilter, "function $($TypeDefinitionAst.Name)")
    <#
        I couldn't come up with a regex that updated the methods without also
        stepping on the class properties, so I just apply the regex against directly
        to the method line number.
    #>
    foreach ($method in $return.Keys.Where( {$PSItem -match "^Method\."}))
    {
        $lineNumber = $return.$method.LineNumber - 1
        $inputModified[$lineNumber] = $inputModified[$lineNumber] -replace $methodFilter, "function "
    }

    $astModified = [System.Management.Automation.Language.Parser]::ParseInput(
        $inputModified, [ref]$tokens, [ref]$null)

    $FunctionDefinitionAst = $astModified.FindAll(
        {$args[0] -is [System.Management.Automation.Language.FunctionDefinitionAst]}, $true)

    Foreach ($Function in $FunctionDefinitionAst)
    {
        $keyName = ($return.Keys.Where( {$PSitem -match ".\.$($Function.Extent.StartLineNumber)"}))[0]

        [void] $return[$keyName].Add('Help', $Function.GetHelpContent())
    }

    return $return
}

function New-WikiPage
{
    [OutputType([hashtable])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [string]
        $Path,

        [Parameter(Mandatory = $true)]
        [string]
        $OutputPath
    )

    begin
    {
    }

    process
    {
        $wikiContent = Get-WikiContent -Path $Path

        $helpFileStrings = [System.Collections.ArrayList]@()
        $linkTable = [System.Collections.ArrayList]@('')

        #region Header

        $classKey = ($wikiContent.Keys.Where( {$PSitem -match 'Class\.'}))[0]
        #$classDefinition = $TypeDefinitionAstForHelp.Where({$PSItem.Name -eq $TypeDefinitionAst.Name})
        #$helpString = Get-HelpString -FunctionDefinitionAst $classDefinition -Property DESCRIPTION

        $class = $wikiContent[$classKey]
        $description = Format-HelpString -String $class.Help.Description
        [void]$helpFileStrings.Add(($header -f $class.Name, $description))
        #endregion

        #region Constructors
        $constructorKeyList = $wikiContent.Keys.Where( {$PSitem -match 'Constructor\.'})
        [void]$helpFileStrings.Add($constructorHeader)

        foreach ($constructorKey in $constructorKeyList.GetEnumerator())
        {
            $constructor = $wikiContent[$constructorKey]
            $link = ($constructor.Link -split "\:")[0]
            $synopsis = Format-HelpString -String $constructor.Help.Synopsis -SingleLine

            $parameterString = $constructor.Parameters.Attributes.TypeName.Name -join ","

            $constructorEntry = "| [$($constructor.name)($parameterString)]$link | $synopsis |"
            [void] $helpFileStrings.Add($constructorEntry)
            [void] $linkTable.Add($constructor.Link)
        }

        #endregion

        #region Properties
        $propertyKeyList = $wikiContent.Keys.Where( {$PSitem -match 'Property\.'})
        [void]$helpFileStrings.Add($propertiesHeader)

        Foreach ($propertyKey in $propertyKeyList.GetEnumerator())
        {
            # TO DO - Resolve property names and add them to the link table
            # |[StigRuleId][Property.StigRuleId] | The Id of an individual Stig Rule. |
            # |[Value][Property.Value] | The specific organizational value to set for the associated Stig rule. |
            $property = $wikiContent[$propertyKey]

            $link = ($property.Link -split "\:")[0]
            $helpString = $class.Help.Parameters[$property.Name.ToUpper()]
            $synopsis = Format-HelpString -String $helpString -SingleLine
            $propertyEntry = "| {0} | {1} |" -f "[$($property.Name)]$link", $synopsis
            [void] $helpFileStrings.Add($propertyEntry)
            [void] $linkTable.Add($property.Link)
        }
        #endregion

        #region Methods
        $methodKeyList = $wikiContent.Keys.Where( {$PSitem -match 'Method\.'})
        [void]$helpFileStrings.Add($methodsHeader)

        Foreach ($methodKey in $methodKeyList.GetEnumerator())
        {
            # TO DO - Resolve property names and add them to the link table
            #| [PropertyMap()][Method.PropertyMap] | The mapping of Stig rule types to the property needing to be modified within the Stig rule. |
            #| [ConvertFrom(xml)][Method.ConvertFrom.Xml] | Converts a provided Xml document into an OrganizationalSetting array. |
            #| [ConvertFrom(hashtable)][Method.ConvertFrom.Hashtable] | Converts a provided Hashtable into an OrganizationalSetting array. |

            $method = $wikiContent[$methodKey]
            $link = ($method.Link -split "\:")[0]
            $synopsis = Format-HelpString -String $method.Help.Synopsis -SingleLine

            $parameterString = $method.Parameters.Attributes.TypeName.Name -join ","
            $methodEntry = "| [$($method.name)($parameterString)]$link | $synopsis |"
            [void] $helpFileStrings.Add($methodEntry)
            [void] $linkTable.Add($method.Link)
        }
        #endregion
        <#
        #region Examples

        [void]$helpFileStrings.Add($examplesHeader)

        foreach($example in $examples)
        {
            "```PowerShell`n$example`n``` "
        }
        #endregion

        #>


        [void]$helpFileStrings.Add($linkTable)

        $file = Get-Item -Path $path

        $helpFileStrings | Out-File -FilePath $OutputPath\"$($file.BaseName).md"
    }

    end
    {
    }
}

function Format-HelpString
{
    [OutputType([string])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory=$true)]
        [string]
        $String,

        [Parameter()]
        [switch]
        $SingleLine
    )

    $returnString = $String -split "`n" -join " "

    if($SingleLine)
    {
        $returnString = $returnString -replace "\.\s+",". "
    }
    else
    {
        $returnString = $returnString -replace "\.\s+",".`n"
    }

    return $returnString.TrimEnd()
}

<#
    .SYNOPSIS
        Insters a blank line before help block.
    .NOTES
        The GetHelpContent methd does not return help if the previous line is not blank.
#>
function Format-BlockComments
{
    [OutputType([string])]
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [string]
        $String
    )

    $String -replace "\<#", "`n<#"
}

Export-ModuleMember -Function 'New-WikiPage'
