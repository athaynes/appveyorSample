$script:ModuleName = 'Release'
$script:moduleRootPath = Split-Path -Path (Split-Path -Path $PSScriptRoot -Parent) -Parent
<#
try
{
    Import-Module -Name (Join-Path -Path $script:moduleRootPath -ChildPath (
        Join-Path -Path $script:ModuleName -ChildPath "$($script:ModuleName).psm1")) -Force

    InModuleScope $script:ModuleName {

        Describe 'Test-GitInstalled' {
            $mockReturn = @{
                'CommandType' = 'Application'
                'Name' = 'git.exe'
                'Version' = '2.15.1.2'
                'Source' = 'C:\Program Files\Git\cmd\git.exe'
            }

            It "Should Throw if Git is not installed" {
                Mock -CommandName Get-Command -MockWith { return $null }
                { Test-GitInstalled } | Should Throw
            }
            It "Should not return anything" {
                Mock -CommandName Get-Command -MockWith { return $mockReturn }
                Test-GitInstalled | Should BeNullOrEmpty
            }
        }

        Describe 'Test-PowerStigRepository' {

            $repositoryList = @(
                @{
                    Name = 'https://github.com/Microsoft/PowerStig.git'
                    Result = @{
                        'html_url' = 'https://github.com/Microsoft/PowerStig'
                        'api_url' = 'https://api.github.com/repos/Microsoft/PowerStig'
                    }
                },
                @{
                    Name = 'https://github.com/Microsoft/PowerStigDsc.git'
                    Result = @{
                        'html_url' = 'https://github.com/Microsoft/PowerStigDsc'
                        'api_url' = 'https://api.github.com/repos/Microsoft/PowerStigDsc'
                    }
                }
            )

            foreach ($repository in $repositoryList)
            {
                Mock -CommandName Invoke-Command -MockWith { return $repository.Name }
                $PowerStigRepository = Test-PowerStigRepository

                It "Should return the correct html URL" {
                    $PowerStigRepository.html_url | Should Be $repository.Result.html_url
                }
                It "Should return the correct Api URL" {
                    $PowerStigRepository.api_url | Should Be $repository.Result.api_url
                }
            }

            It "Should throw an error if a non PowerStig project is suplied" {
                $repository = 'https://github.com/Microsoft/NotPowerStig.git'
                Mock -CommandName Invoke-Command -MockWith { return $repository }
                { Test-PowerStigRepository } | Should throw
            }

        }

        Describe 'Set-GitBranch' {
            $branch = 'dev'

            Context 'Already in dev Branch' {
                Mock -CommandName Get-GitBranch -MockWith { return $branch }
                Mock -CommandName Invoke-Command -MockWith { return } -Verifiable
                It "Should not invoke 'git checkout $branch" {
                    Set-GitBranch -Branch $branch
                    Assert-MockCalled -CommandName Invoke-Command -ParameterFilter { $ScriptBlock.ToString() -match "git checkout" } -Times 0
                }
            }

            Context 'Not already in dev Branch' {
                Mock -CommandName Get-GitBranch -MockWith { return 'master' }
                Mock -CommandName Invoke-Command -MockWith { return } `
                    -ParameterFilter { $ScriptBlock.ToString() -match "git checkout" } -Verifiable
                It "Should invoke 'git checkout $branch" {
                    Set-GitBranch -Branch $branch
                    Assert-MockCalled -CommandName Invoke-Command -Times 1
                }
            }

            Context 'SkipPull' {
                Mock -CommandName Get-GitBranch -MockWith { return $branch }
                Mock -CommandName Invoke-Command -MockWith { return } -Verifiable
                It "Should not invoke a pull when SkipPull is used" {
                    Set-GitBranch -Branch $branch -SkipPull
                    Assert-MockCalled -CommandName Invoke-Command -ParameterFilter { $ScriptBlock.ToString() -match "git pull" } -Times 0
                }
            }
        }

        Describe 'Push-DevBranch' {

            Mock -CommandName Invoke-Command -MockWith { return } -ParameterFilter {$ScriptBlock.ToString() -match 'git commit -a -m'} -Verifiable
            Mock -CommandName Invoke-Command -MockWith { return } -ParameterFilter {$ScriptBlock.ToString() -match 'git push'} -Verifiable

            It "Should Commit and push the dev" {
                Push-DevBranch
                Assert-MockCalled -CommandName Invoke-Command -Times 2
            }
        }

        Describe 'Get-UnreleasedNotes' {
            $sampleReadme = New-Object System.Text.StringBuilder
            $null = $sampleReadme.AppendLine('')
            $null = $sampleReadme.AppendLine('### Unreleased')
            $null = $sampleReadme.AppendLine('')
            $null = $sampleReadme.AppendLine('Update 1')
            $null = $sampleReadme.AppendLine('Update 2')
            $null = $sampleReadme.AppendLine('')
            $null = $sampleReadme.AppendLine('### 1.0.0.0')
            $null = $sampleReadme.AppendLine('')

            Mock -CommandName Get-ChildItem -MockWith { return @{'FullName' = 'empty\path'} }
            Mock -CommandName Get-Content -MockWith { return $sampleReadme.ToString().Split("`n") }

            It "Should return the unreleased notes trimmed of extra lines" {
                Get-UnreleasedNotes | Should Be ("Update 1`r`r`nUpdate 2" | Out-String).Trim()
            }
        }

        Describe 'Update-ReadmeReleaseNotes' {

        }

        Describe 'Update-Manifest' {

        }

        Describe 'Get-GitHubApiKey' {

        }

        Describe 'Get-GitHubRefStatus' {

            $stateList = @('pending', 'failure', 'success')
            $gitHubApiKey = 'TestApiKey' | ConvertTo-SecureString -AsPlainText -Force
            $repository = @{}

            Foreach ($state in $stateList)
            {
                It "Should return '$state' from rest API" {
                    Mock -CommandName Invoke-RestMethod -MockWith { return @{ 'state' = $state } }
                    $status = Get-GitHubRefStatus -Repository $repository -Name test -GitHubApiKey $gitHubApiKey
                    $status | Should Be $state
                }
            }

            It "Should wait for 'pending' to change to complete" {
                # TO DO figure out how to test a looping function when the WaitForSuccess switch is set
            }
        }

        Describe 'New-GitHubPullRequest' {

        }

        Describe 'Approve-GitHubPullRequest' {

        }

        Describe 'New-PowerStigRelease' {

        }
    }
}
finally
{

}
#>
