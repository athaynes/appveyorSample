Describe 'appveyorSample' {
    It 'Shld be True' {
        $true | Should Be $true
    }
}
